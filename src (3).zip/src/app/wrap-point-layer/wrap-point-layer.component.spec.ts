import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WrapPointLayerComponent } from './wrap-point-layer.component';

describe('WrapPointLayerComponent', () => {
  let component: WrapPointLayerComponent;
  let fixture: ComponentFixture<WrapPointLayerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WrapPointLayerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WrapPointLayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
