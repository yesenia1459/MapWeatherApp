import { Component, OnInit , Input} from '@angular/core';


@Component({
  selector: 'app-wrap-point-layer',
  templateUrl: './wrap-point-layer.component.html',
  styleUrls: ['./wrap-point-layer.component.css']
})
export class WrapPointLayerComponent implements OnInit {
@Input() alertdata: JSON;
alertdata2:JSON;
name:string
  constructor() { }

  ngOnInit() {
    this.alertdata2=this.alertdata;
  }

}
