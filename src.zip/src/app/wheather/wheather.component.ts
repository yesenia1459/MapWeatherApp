import { Component, OnInit ,Input, OnChanges} from '@angular/core';
import { HttpClient } from '@angular/common/http';



@Component({
  selector: 'app-wheather',
  templateUrl: './wheather.component.html',
  styleUrls: ['./wheather.component.css']
})

export class WheatherComponent implements OnChanges,OnInit {
  
  @Input() lat: string;
  @Input() lng: string;
  
  public city:string;
  public temp:number;
  public location: string;
  public weatherIconUrl: string;
  public weatherText: string;
  public temperatureValue: number;
  public temperatureUnit: string;
  public isDaytime: boolean;
  icon: string;
  public country: string;
  public humidity: string;
  public fecha:Date;

  constructor(private http: HttpClient) {
   
   }

  
  ngOnChanges() {
    let url = 'http://api.openweathermap.org/data/2.5/weather?'
    + 'lat=' + this.lat
    + '&lon=' + this.lng
    + '&units=metric'
    + '&lang=en'
    + '&appid=1e67964ef3b67d111fa749c2bb22d901'; // your api key here

    this.http.get(url).subscribe((data: any) => {
      console.log(data);
      this.icon= data.weather[0].icon;
      this.city = data.name;
      this.temp = data.main.temp.toFixed(1);      
      this.weatherText = data.weather[0].main;
      this.isDaytime = true ;//currentConditions.IsDayTime;
      this.weatherIconUrl = "http://openweathermap.org/img/w/" +data.weather[0].icon + ".png",
      this.temperatureValue = data.main.temp;
      this.country = data.sys.country;
      this.temperatureUnit = data.main.temperatureUnit;
      this.humidity = data.main.humidity;
      this.fecha= new Date(data.dt*1000)
   });

    
    


 

  }

  ngOnInit() {
    let url = 'http://api.openweathermap.org/data/2.5/weather?'
    + 'lat=' + this.lat
    + '&lon=' + this.lng
    + '&units=metric'
    + '&lang=en'
    + '&appid=1e67964ef3b67d111fa749c2bb22d901'; // your api key here

    this.http.get(url).subscribe((data: any) => {
      console.log(data);
      this.city = data.name;
      this.temp = data.main.temp.toFixed(1);
   });

   /*
   this.http.get(url).toPromise().then((data: any) => {
    console.log(data); 
 });*/

 

  }

}
